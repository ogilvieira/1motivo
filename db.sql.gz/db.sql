# Migração da Base de Dados MySQL do WordPress
#
# Gerado: Saturday 5. November 2016 01:58 UTC
# Nome do Servidor: 127.0.0.1
# Banco de Dados: `1motivo`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Apagar qualquer tabela `1m_commentmeta` existente
#

DROP TABLE IF EXISTS `1m_commentmeta`;


#
# Estrutura da tabela `1m_commentmeta`
#

CREATE TABLE `1m_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_commentmeta`
#

#
# Fim do conteúdo da tabela `1m_commentmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_comments` existente
#

DROP TABLE IF EXISTS `1m_comments`;


#
# Estrutura da tabela `1m_comments`
#

CREATE TABLE `1m_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_comments`
#
INSERT INTO `1m_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2016-11-04 21:37:00', '2016-11-04 21:37:00', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'post-trashed', '', '', 0, 0) ;

#
# Fim do conteúdo da tabela `1m_comments`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_links` existente
#

DROP TABLE IF EXISTS `1m_links`;


#
# Estrutura da tabela `1m_links`
#

CREATE TABLE `1m_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` longtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_links`
#

#
# Fim do conteúdo da tabela `1m_links`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_options` existente
#

DROP TABLE IF EXISTS `1m_options`;


#
# Estrutura da tabela `1m_options`
#

CREATE TABLE `1m_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_options`
#
INSERT INTO `1m_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http:1motivo.web2423.uni5.net', 'yes'),
(2, 'home', 'http:1motivo.web2423.uni5.net', 'yes'),
(3, 'blogname', '1motivo', 'yes'),
(4, 'blogdescription', 'é tudo que você precisa', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'ogilvieira@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%category%/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:29:"rss-importer/rss-importer.php";i:1;s:41:"wordpress-importer/wordpress-importer.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', '', 'no'),
(41, 'template', 'mytheme', 'yes'),
(42, 'stylesheet', 'mytheme', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '37965', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '1', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'page', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:0:{}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:0:{}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '4', 'yes'),
(85, 'page_on_front', '6', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '29630', 'yes'),
(89, '1m_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:6:{i:1478338629;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1478381940;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1478384461;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1478392556;a:1:{s:26:"importer_scheduled_cleanup";a:1:{s:32:"dd07e4db14c3f5ea561b3bed7428c6ab";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:16;}}}}i:1478392600;a:1:{s:26:"importer_scheduled_cleanup";a:1:{s:32:"8ed56e6c25286330953b4891a51c25d9";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:17;}}}}s:7:"version";i:2;}', 'yes'),
(125, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(126, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(127, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(128, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(129, 'rewrite_rules', 'a:92:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:31:".+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:".+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:".+?/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"(.+?)/([^/]+)/embed/?$";s:63:"index.php?category_name=$matches[1]&name=$matches[2]&embed=true";s:26:"(.+?)/([^/]+)/trackback/?$";s:57:"index.php?category_name=$matches[1]&name=$matches[2]&tb=1";s:46:"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:41:"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:34:"(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]";s:41:"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:30:"(.+?)/([^/]+)(?:/([0-9]+))?/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]";s:20:".+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:".+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:".+?/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:38:"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:14:"(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:26:"(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:33:"(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&cpage=$matches[2]";s:8:"(.+?)/?$";s:35:"index.php?category_name=$matches[1]";}', 'yes'),
(130, 'finished_splitting_shared_terms', '1', 'yes') ;
INSERT INTO `1m_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(131, 'site_icon', '0', 'yes'),
(132, 'medium_large_size_w', '768', 'yes'),
(133, 'medium_large_size_h', '0', 'yes'),
(134, 'db_upgraded', '', 'yes'),
(137, 'can_compress_scripts', '1', 'no'),
(140, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1478296796;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(141, 'current_theme', 'mplsagc', 'yes'),
(142, 'theme_mods_mytheme', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}}', 'yes'),
(143, 'theme_switched', '', 'yes'),
(147, 'WPLANG', 'pt_BR', 'yes'),
(155, 'recently_activated', 'a:0:{}', 'yes'),
(168, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(217, 'category_children', 'a:0:{}', 'yes') ;

#
# Fim do conteúdo da tabela `1m_options`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_postmeta` existente
#

DROP TABLE IF EXISTS `1m_postmeta`;


#
# Estrutura da tabela `1m_postmeta`
#

CREATE TABLE `1m_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_postmeta`
#
INSERT INTO `1m_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_edit_last', '1'),
(3, 4, '_wp_page_template', 'default'),
(4, 4, '_edit_lock', '1478297927:1'),
(5, 6, '_edit_last', '1'),
(6, 6, '_wp_page_template', 'default'),
(7, 6, '_edit_lock', '1478297936:1'),
(8, 2, '_wp_trash_meta_status', 'publish'),
(9, 2, '_wp_trash_meta_time', '1478298084'),
(10, 2, '_wp_desired_post_slug', 'sample-page'),
(11, 9, '_menu_item_type', 'post_type'),
(12, 9, '_menu_item_menu_item_parent', '0'),
(13, 9, '_menu_item_object_id', '6'),
(14, 9, '_menu_item_object', 'page'),
(15, 9, '_menu_item_target', ''),
(16, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(17, 9, '_menu_item_xfn', ''),
(18, 9, '_menu_item_url', ''),
(20, 10, '_menu_item_type', 'post_type'),
(21, 10, '_menu_item_menu_item_parent', '0'),
(22, 10, '_menu_item_object_id', '4'),
(23, 10, '_menu_item_object', 'page'),
(24, 10, '_menu_item_target', ''),
(25, 10, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(26, 10, '_menu_item_xfn', ''),
(27, 10, '_menu_item_url', ''),
(29, 11, '_menu_item_type', 'post_type'),
(30, 11, '_menu_item_menu_item_parent', '0'),
(31, 11, '_menu_item_object_id', '6'),
(32, 11, '_menu_item_object', 'page'),
(33, 11, '_menu_item_target', ''),
(34, 11, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(35, 11, '_menu_item_xfn', ''),
(36, 11, '_menu_item_url', ''),
(37, 11, '_menu_item_orphaned', '1478301352'),
(38, 12, '_menu_item_type', 'custom'),
(39, 12, '_menu_item_menu_item_parent', '0'),
(40, 12, '_menu_item_object_id', '12'),
(41, 12, '_menu_item_object', 'custom'),
(42, 12, '_menu_item_target', ''),
(43, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(44, 12, '_menu_item_xfn', ''),
(45, 12, '_menu_item_url', '#'),
(47, 13, '_menu_item_type', 'custom'),
(48, 13, '_menu_item_menu_item_parent', '0'),
(49, 13, '_menu_item_object_id', '13'),
(50, 13, '_menu_item_object', 'custom'),
(51, 13, '_menu_item_target', ''),
(52, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(53, 13, '_menu_item_xfn', ''),
(54, 13, '_menu_item_url', '#'),
(56, 14, '_menu_item_type', 'custom'),
(57, 14, '_menu_item_menu_item_parent', '0'),
(58, 14, '_menu_item_object_id', '14'),
(59, 14, '_menu_item_object', 'custom'),
(60, 14, '_menu_item_target', ''),
(61, 14, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(62, 14, '_menu_item_xfn', ''),
(63, 14, '_menu_item_url', '#'),
(65, 15, '_menu_item_type', 'custom'),
(66, 15, '_menu_item_menu_item_parent', '0'),
(67, 15, '_menu_item_object_id', '15'),
(68, 15, '_menu_item_object', 'custom'),
(69, 15, '_menu_item_target', ''),
(70, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(71, 15, '_menu_item_xfn', ''),
(72, 15, '_menu_item_url', '#'),
(74, 16, '_wp_attached_file', '2016/11/feed.xml_.txt'),
(75, 16, '_wp_attachment_context', 'import'),
(78, 1, '_wp_trash_meta_status', 'publish'),
(79, 1, '_wp_trash_meta_time', '1478306271'),
(80, 1, '_wp_desired_post_slug', 'hello-world'),
(81, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(82, 18, '_wp_trash_meta_status', 'publish'),
(83, 18, '_wp_trash_meta_time', '1478306272'),
(84, 18, '_wp_desired_post_slug', 'obrigado-luan-vicente'),
(85, 19, '_wp_trash_meta_status', 'publish'),
(86, 19, '_wp_trash_meta_time', '1478306272'),
(87, 19, '_wp_desired_post_slug', 'me-sinto-seguro-no-onibus'),
(88, 20, '_wp_trash_meta_status', 'publish'),
(89, 20, '_wp_trash_meta_time', '1478306273'),
(90, 20, '_wp_desired_post_slug', 'eu-tinha-o-mesmo-problema-resolvi-criando-uma-conta-gmail-pro-youtube-para-me-inscrever-apenas-em'),
(91, 21, '_wp_trash_meta_status', 'publish'),
(92, 21, '_wp_trash_meta_time', '1478306273'),
(93, 21, '_wp_desired_post_slug', 'com-bilhete-unico-mensal-vc-paga-140-e-pode-rodar-quantas-vezes-quiser-de-onibus-por-mes-fica-a'),
(94, 22, '_wp_trash_meta_status', 'publish'),
(95, 22, '_wp_trash_meta_time', '1478306274'),
(96, 22, '_wp_desired_post_slug', 'estou-aqui-pela-premonicao-contida-neste-titulo-e-imagem-de-destaque'),
(97, 25, '_wp_trash_meta_status', 'publish'),
(98, 25, '_wp_trash_meta_time', '1478306275'),
(99, 25, '_wp_desired_post_slug', 'adorei-o-texto-me-fez-lembrar-do-passado-comparar-com-o-que-penso-agora-com-outras-experiencias'),
(100, 27, '_wp_trash_meta_status', 'publish'),
(101, 27, '_wp_trash_meta_time', '1478306275'),
(102, 27, '_wp_desired_post_slug', 'ola-douglas'),
(103, 26, '_edit_last', '1'),
(106, 26, '_edit_lock', '1478306619:1'),
(107, 24, '_edit_last', '1'),
(110, 24, '_edit_lock', '1478306698:1'),
(111, 23, '_edit_last', '1'),
(114, 23, '_edit_lock', '1478310879:1') ;
INSERT INTO `1m_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(115, 23, '_oembed_34e31715f85498dac1ff48b4fb5d55f7', '{{unknown}}') ;

#
# Fim do conteúdo da tabela `1m_postmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_posts` existente
#

DROP TABLE IF EXISTS `1m_posts`;


#
# Estrutura da tabela `1m_posts`
#

CREATE TABLE `1m_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `pinged` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_posts`
#
INSERT INTO `1m_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-11-04 21:37:00', '2016-11-04 21:37:00', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2016-11-05 00:37:51', '2016-11-05 00:37:51', '', 0, 'http:1motivo.web2423.uni5.net/?p=1', 0, 'post', '', 1),
(2, 1, '2016-11-04 21:37:00', '2016-11-04 21:37:00', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http:1motivo.web2423.uni5.net/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'open', 'open', '', 'sample-page__trashed', '', '', '2016-11-04 22:21:24', '2016-11-04 22:21:24', '', 0, 'http:1motivo.web2423.uni5.net/?page_id=2', 0, 'page', '', 0),
(3, 1, '2016-11-04 21:37:18', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-11-04 21:37:18', '0000-00-00 00:00:00', '', 0, 'http:1motivo.web2423.uni5.net/?p=3', 0, 'post', '', 0),
(4, 1, '2016-11-04 22:21:07', '2016-11-04 22:21:07', '', 'Artigos', '', 'publish', 'closed', 'closed', '', 'artigos', '', '', '2016-11-04 22:21:07', '2016-11-04 22:21:07', '', 0, 'http:1motivo.web2423.uni5.net/?page_id=4', 0, 'page', '', 0),
(5, 1, '2016-11-04 22:21:07', '2016-11-04 22:21:07', '', 'Artigos', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2016-11-04 22:21:07', '2016-11-04 22:21:07', '', 4, 'http:1motivo.web2423.uni5.net/?p=5', 0, 'revision', '', 0),
(6, 1, '2016-11-04 22:21:17', '2016-11-04 22:21:17', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2016-11-04 22:21:17', '2016-11-04 22:21:17', '', 0, 'http:1motivo.web2423.uni5.net/?page_id=6', 0, 'page', '', 0),
(7, 1, '2016-11-04 22:21:17', '2016-11-04 22:21:17', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2016-11-04 22:21:17', '2016-11-04 22:21:17', '', 6, 'http:1motivo.web2423.uni5.net/?p=7', 0, 'revision', '', 0),
(8, 1, '2016-11-04 22:21:24', '2016-11-04 22:21:24', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http:1motivo.web2423.uni5.net/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-11-04 22:21:24', '2016-11-04 22:21:24', '', 2, 'http:1motivo.web2423.uni5.net/?p=8', 0, 'revision', '', 0),
(9, 1, '2016-11-04 23:16:23', '2016-11-04 23:16:23', ' ', '', '', 'publish', 'closed', 'closed', '', '9', '', '', '2016-11-04 23:16:29', '2016-11-04 23:16:29', '', 0, 'http:1motivo.web2423.uni5.net/?p=9', 1, 'nav_menu_item', '', 0),
(10, 1, '2016-11-04 23:16:23', '2016-11-04 23:16:23', ' ', '', '', 'publish', 'closed', 'closed', '', '10', '', '', '2016-11-04 23:16:29', '2016-11-04 23:16:29', '', 0, 'http:1motivo.web2423.uni5.net/?p=10', 2, 'nav_menu_item', '', 0),
(11, 1, '2016-11-04 23:15:51', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-04 23:15:51', '0000-00-00 00:00:00', '', 0, 'http:1motivo.web2423.uni5.net/?p=11', 1, 'nav_menu_item', '', 0),
(12, 1, '2016-11-04 23:16:24', '2016-11-04 23:16:24', '', 'LOREM IPSUM', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum', '', '', '2016-11-04 23:16:29', '2016-11-04 23:16:29', '', 0, 'http:1motivo.web2423.uni5.net/?p=12', 3, 'nav_menu_item', '', 0),
(13, 1, '2016-11-04 23:16:24', '2016-11-04 23:16:24', '', 'LOREM IPSUM', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-2', '', '', '2016-11-04 23:16:29', '2016-11-04 23:16:29', '', 0, 'http:1motivo.web2423.uni5.net/?p=13', 4, 'nav_menu_item', '', 0),
(14, 1, '2016-11-04 23:16:24', '2016-11-04 23:16:24', '', 'LOREM IPSUM', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-3', '', '', '2016-11-04 23:16:29', '2016-11-04 23:16:29', '', 0, 'http:1motivo.web2423.uni5.net/?p=14', 5, 'nav_menu_item', '', 0),
(15, 1, '2016-11-04 23:16:24', '2016-11-04 23:16:24', '', 'LOREM IPSUM', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-4', '', '', '2016-11-04 23:16:29', '2016-11-04 23:16:29', '', 0, 'http:1motivo.web2423.uni5.net/?p=15', 6, 'nav_menu_item', '', 0),
(16, 1, '2016-11-05 00:35:56', '2016-11-05 00:35:56', 'http:1motivo.web2423.uni5.net/wp-content/uploads/2016/11/feed.xml_.txt', 'feed.xml_.txt', '', 'private', 'open', 'closed', '', 'feed-xml_-txt', '', '', '2016-11-05 00:35:56', '2016-11-05 00:35:56', '', 0, 'http:1motivo.web2423.uni5.net/wp-content/uploads/2016/11/feed.xml_.txt', 0, 'attachment', '', 0),
(18, 1, '2016-09-26 15:41:58', '2016-09-26 15:41:58', '<p>Obrigado <a href="https://medium.com/u/d270872c8b23">Luan Vicente</a>! Eu sou um portador (de verdade) de TDAH. Eu tive que escolher em basear minha vida em remédios controladores ou criar alguma disciplina e estratégias para combater as coisas ruins que me atrapalham por causa dessa condição. Depois de muita leitura nesses últimos 5 anos alguma coisa de experiência eu tenho para contar hehehe. Obrigado! tomara que eu consiga produzir mais coisas que sejam minimamente úteis pra quem tem problemas parecidos com os meus. Até mais!</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=5794419e5d79" width="1" height="1">', 'Obrigado Luan Vicente!', '', 'trash', 'open', 'open', '', 'obrigado-luan-vicente__trashed', '', '', '2016-11-05 00:37:52', '2016-11-05 00:37:52', '', 0, 'https://medium.com/p/5794419e5d79', 0, 'post', '', 0),
(19, 1, '2016-09-24 03:58:27', '2016-09-24 03:58:27', '<p>Me sinto seguro no ônibus. Raramente pode acontecer de aparecer alguem estranho, geralmente é tranquilo para usar smartphone, kindle…</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=97838e223517" width="1" height="1">', 'Me sinto seguro no ônibus.', '', 'trash', 'open', 'open', '', 'me-sinto-seguro-no-onibus__trashed', '', '', '2016-11-05 00:37:52', '2016-11-05 00:37:52', '', 0, 'https://medium.com/p/97838e223517', 0, 'post', '', 0),
(20, 1, '2016-09-24 03:46:04', '2016-09-24 03:46:04', '<p>Eu tinha o mesmo problema, resolvi criando uma conta gmail pro youtube para me inscrever apenas em canais de video aula. Quem sabe isso pode te ajudar também.</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=be2c75de30ff" width="1" height="1">', 'Eu tinha o mesmo problema, resolvi criando uma conta gmail pro youtube para me inscrever apenas em…', '', 'trash', 'open', 'open', '', 'eu-tinha-o-mesmo-problema-resolvi-criando-uma-conta-gmail-pro-youtube-para-me-inscrever-apenas-em__trashed', '', '', '2016-11-05 00:37:53', '2016-11-05 00:37:53', '', 0, 'https://medium.com/p/be2c75de30ff', 0, 'post', '', 0),
(21, 1, '2016-09-23 11:33:00', '2016-09-23 11:33:00', '<p>Com bilhete único mensal, vc paga 140 e pode rodar quantas vezes quiser de ônibus por mês… fica a dica! Ônibus para o trabalho é muito vantajoso quanto a otimização de tempo, eu apoio!</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=8e78970d77dc" width="1" height="1">', 'Com bilhete único mensal, vc paga 140 e pode rodar quantas vezes quiser de ônibus por mês… fica a…', '', 'trash', 'open', 'open', '', 'com-bilhete-unico-mensal-vc-paga-140-e-pode-rodar-quantas-vezes-quiser-de-onibus-por-mes-fica-a__trashed', '', '', '2016-11-05 00:37:54', '2016-11-05 00:37:54', '', 0, 'https://medium.com/p/8e78970d77dc', 0, 'post', '', 0),
(22, 1, '2016-09-22 02:58:14', '2016-09-22 02:58:14', '<p>Estou aqui pela premonição contida neste titulo e imagem de destaque</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=572f4a21d402" width="1" height="1">', 'Estou aqui pela premonição contida neste titulo e imagem de destaque', '', 'trash', 'open', 'open', '', 'estou-aqui-pela-premonicao-contida-neste-titulo-e-imagem-de-destaque__trashed', '', '', '2016-11-05 00:37:54', '2016-11-05 00:37:54', '', 0, 'https://medium.com/p/572f4a21d402', 0, 'post', '', 0),
(23, 1, '2016-09-21 04:22:43', '2016-09-21 04:22:43', '<h4>Um guia realista sobre como se esquivar dessa falta de coragem para realizar coisas.</h4>\r\n<figure><img src="https://d262ilb51hltx0.cloudfront.net/max/1024/1*u3znrnUxKFqDrzan9AV6pQ.png" alt="" />\r\n<figcaption>Se você é do tipo que realmente precisa ler este artigo, é muito provável que não passe daqui…</figcaption></figure>Ok, você já sabe que todos nós sofremos com preguiça, alguns de nós são verdadeiras mulas empacadas no sofá pois, “Por inércia, um corpo em repouso tende a continuar em repouso”.\r\n\r\nVocê provavelmente também já sabe, caso já tenha procurado ajuda na internet antes, que o melhor jeito de se livrar da preguiça é “<strong>Fazer Algo</strong>”, quem sabe acordar ás 6 da manhã e fazer exercícios…\r\n\r\nO meu problema com isso é o seguinte:\r\n<blockquote>Como fazer algo para se livrar da preguiça sendo que a preguiça não me deixa fazer algo?</blockquote>\r\n<img class="aligncenter size-medium" src="https://media.giphy.com/media/p7xQlayxs6Uda/giphy.gif" alt="" width="400" height="226" />\r\n<h3></h3>\r\n<h3>Aceitando a Derrota</h3>\r\nSejamos honestos, a preguiça sempre ira vencer e você sabe disso; a Netflix sabe disso; o YouTube sabe disso e mantem uma playlist reservada pra te foder no limbo da procrastinação. Para nos livrarmos das amarras da “Falta de vontade de fazer qualquer coisa”, vamos precisar de atitudes simples que possam ser realizadas mesmo naquelas manhãs de domingo.\r\n<h4>1) Dormir de forma inteligente</h4>\r\nO sono é composto de <a href="http://www.sono.org.br/sono/sono.php">ciclos</a> de 1h30m entre o estados mais profundo (REM) e mais leve. A sensação de cansaço ao acordar geralmente é maior quando você é despertado durante o estágio do sono REM, sabendo disso, você pode usar <a href="https://play.google.com/store/apps/details?id=com.cycle.sleepcalculator">apps que calculam o melhor horário para acordar</a> com base na hora em que pretende dormir. Programe o alarme para te acordar no momento exato sem perder disposição, e pronto.\r\n<h4>2) Fazer pouco é melhor que fazer nada</h4>\r\n<figure><img src="https://d262ilb51hltx0.cloudfront.net/max/690/1*oUeJDE0pNDbrdGHD1H_ksQ.jpeg" alt="" /></figure>Se você planeja criar um novo hábito, como escrever um blog, por exemplo, você pode tentar se cobrar de escrever apenas uma linha por dia. Isso mesmo, vá aos poucos, o mais importante é a ignição, se não rolar tudo bem, volte amanhã e tente outra vez.\r\n<h4>3) Pequenas tarefas criam grandes monstros</h4>\r\nEvite deixar que pequenas tarefas se acumulem, pegue tudo que for muito fácil e rápido de se fazer e apenas faça.\r\n<h4>4) Divida tarefas longas em partes menores</h4>\r\nSe você nunca ouviu falar da técnica Pomodoro, saiba que esta perdendo uma das grandes soluções anti-procrastinação na hora de encarar tarefas grandes. Na técnica Pomodoro, basicamente, você divide o tempo em ciclos de 25 minutos para focar em sua tarefa e mais 5 minutos de pausa fazendo algo que goste. a cada 4 ciclos, tire uma pausa maior de 15 minutos. Você pode procurar por <strong>Pomodoro</strong> em sua app store, existem diversos aplicativos para ajudar a gerenciar estes ciclos.\r\n\r\n<figure><img src="https://d262ilb51hltx0.cloudfront.net/max/1024/1*kZzipFPSUMrR12ymvrxE1Q.jpeg" alt="" /></figure>O Pomodoro ajuda a se sentir recompensado pelo trabalho nas pausas, e aumentar sua produtiva nos momentos de foco absoluto. <a href="https://pt.wikipedia.org/wiki/T%C3%A9cnica_pomodoro">Saiba mais aqui</a>.\r\n<h4><strong>5) Dificulte a procrastinação</strong></h4>\r\nSe você se perde no buraco negro de links do YouTube, Medium, Facebook, Twitter… saiba que dá pra fugir com soluções simples: Você pode usar extensões para Chrome como o <a href="https://chrome.google.com/webstore/detail/block-site/eiimnmioipafcokbfikbljfdeojpcgbh?hl=en">Block Site</a>, bloquear os sites que estão te atrapalhando com senha. Eu peço para alguém criar a senha pra mim, fica mais difícil burlar quando você tem essa barreira social colaborando para sua desistência de procrastinar.\r\n\r\nNo Smartphone a solução é mais simples ainda: Desinstale todos os aplicativos que só servem para te atrapalhar, e isso inclui o Whatsapp. Vá por mim, as pessoas com quem você realmente precisa falar vão te ligar ou estarão sempre perto de você.\r\n<h4>6) Procure um médico</h4>\r\nÉ importante avisar que a preguiça pode estar associadas a algumas doenças e deficiências de vitaminas. Se mesmo com essas dicas você ainda não conseguiu vencer a preguiça, pense a respeito sobre procurar a ajuda de um médico.\r\n<h3>Conclusão</h3>\r\nGosto de pensar que a preguiça só existe quando as coisas estão minimamente confortáveis para nós, mamíferos que repousamos quando não há necessidade de procurar comida ou fugir do predador. Mesmo assim, a roda tem que continuar a rodar e com pequenos hacks podemos manipular nossos instintos e alcançar nossos objetivos. Como já falei em outro artigo: <a href="https://medium.com/@ogilvieira/n%C3%A3o-dependa-da-sua-for%C3%A7a-de-vontade-pois-ela-vai-falhar-49706d3baed8#.57shk5rj2">Não dependa da sua força de vontade, pois ela vai falhar.</a>\r\n<ul>\r\n 	<li><a href="https://medium.com/@ogilvieira/como-aprender-mais-r%C3%A1pido-ed671efdcf47">Como aprender qualquer coisa sozinho, com pouca grana e muito mais rápido</a></li>\r\n 	<li><a href="https://medium.com/@ogilvieira/5-coisas-sobre-ser-autodidata-que-eu-diria-a-mim-mesmo-se-pudesse-voltar-no-tempo-de3006b1e61b">5 coisas sobre ser autodidata que eu diria a mim mesmo se pudesse voltar no tempo</a></li>\r\n</ul>\r\n<img src="https://medium.com/_/stat?event=post.clientViewed&amp;referrerSource=full_rss&amp;postId=b5bfdf14c719" width="1" height="1" />', 'Como se livrar da PREGUIÇA fazendo pouco, ou quase nada', '', 'publish', 'open', 'open', '', 'como-se-livrar-da-preguica-fazendo-pouco-ou-quase-nada', '', '', '2016-11-05 00:54:22', '2016-11-05 00:54:22', '', 0, 'https://medium.com/p/b5bfdf14c719', 0, 'post', '', 0),
(24, 1, '2016-09-02 12:16:28', '2016-09-02 12:16:28', '<h4>Sobre como passamos de jovens rebeldes descontrutores de conceitos a pais de família vítimas de uma sociedade doente.</h4><p>Houve um tempo em que “levar uma vida sem pressão” era um dos meus conselhos; “Deixar que as coisas acontecessem naturalmente” era minha filosofia de vida. Esse tempo morreu no dia em que nasceu minha independência.</p><figure><img alt="" src="https://d262ilb51hltx0.cloudfront.net/max/1024/1*t2No4W1-MuYXG6yB97tFeg.jpeg" /></figure><p>Alguém aparentemente bem sucedido (sem esforço aparente) vai dizer que você não precisa levar a vida a tão sério e que um mochilão pela Europa vai mudar sua vida. Se você não pertence a classe alta deste país, vem comigo neste artigo.</p><p>Quando se mora com os pais, as tarefas domésticas magicamente acontecem. Não nos é muito nítido o quão difícil é administrar uma família. Para uma criação razoável de nossa prole é necessário prover saúde, alimentação, transporte, educação e uma internet boa para que seu filhote possa mostrar a todos o quanto revolucionário ele é, “FUCK THE SYSTEM!”, Certo!?</p><p>Nós eramos mais jovens, queríamos mudar o mundo e o mundo foi quem nos mudou. A sociedade que tanto odiamos coloca a música e vamos arriscando os passos para tentar acompanhar e não ficar de fora do baile. Alguns vieram preparados com seus MBA’s de sapateados e outros são dançarinos dedicados. Deixar esses caras pegarem seu espaço na pista é perder mais que glamour de ser um bom dançarino, é ter que ver seu filho correndo risco de vida por causa de um plano de saúde merda, ter que ver sua filha frustrada por não poder fazer o que ama ou não pagar a internet para que o filhão possa falar sobre “o que os adultos estão fazendo de suas vidas é errado”, pobres adultos, deveriam ouvir meu conselho e fugir desse sistema podre.</p><p>Hey kid, é tudo que gostaríamos de fazer sabe... Infelizmente as contas não param de chegar e sem uma educação de qualidade o junior terá que sofrer tanto quanto ou quem sabe mais que eu, para tentar manter as coisas ordens, <strong>como nossos pais…</strong></p><h4>Ainda somos jovens</h4><p>Manter o equilíbrio é essencial. Entre tentar mudar o mundo e expor a minha arte, há um espaço reservado para bater ponto, ser inovador, aprender algo técnico e flertar por um aumento merecido, quem sabe.</p><p>Outro dia, aqui em São Paulo, um homem desempregado pulou com seu filho de 4 anos do prédio do Fórum Trabalhista. Os dois morreram.</p><p>Da pra imaginar o que se passou pela cabeça daquele homem. Mais uma vítima dessa sociedade patriarcal doente. Eles falam de meritocracia, quem merece sofrer por não ter perspectiva de poder sustentar os filhos?</p><p>Ela, a sociedade, nos faz chorar. E eu choro sim! Não é nada fácil manter as coisas, sabe… Penso em desistir sim, mas lembro que é isso que eles querem e eu não vou deixar.</p><figure><img alt="" src="https://d262ilb51hltx0.cloudfront.net/max/1024/1*MtoVSZapAe99duNQQkzxuA.jpeg" /></figure><h4>Mesmo assim, a vida ainda é bela</h4><p>Acompanhar uma criança crescer, alimentar o lúdico, compartilhar nossas experiências como neste artigo aqui e perceber que em nossas individualidades estamos sendo acompanhados por pessoas que passam pelos mesmos dilemas, medos e dificuldades.</p><p>Por isso, jovem, não leve a vida tão a sério, todo buraco tem saída independente da profundidade; Mas também não amoleça, a vida vai bater forte, e você tem que estar preparado para aguentar firme e continuar levantando.</p><iframe src="https://cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2F85tRr6_1FXQ%3Ffeature%3Doembed&amp;url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D85tRr6_1FXQ&amp;image=https%3A%2F%2Fi.ytimg.com%2Fvi%2F85tRr6_1FXQ%2Fhqdefault.jpg&amp;key=d04bfffea46d4aeda930ec88cc64b87c&amp;type=text%2Fhtml&amp;schema=youtube" width="640" height="480" frameborder="0" scrolling="no"><a href="https://medium.com/media/2d502ca6a187e139ac95e55f1d5c6a19/href">https://medium.com/media/2d502ca6a187e139ac95e55f1d5c6a19/href</a></iframe><p>Gostou do artigo? Deixe aquele seu like motivacional ai!. Se preferir, deixe um comentário e compartilhe o artigo.</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=e3ec6ff0d4d0" width="1" height="1">', 'AC/DC (Antes das Contas/Depois das Contas)', '', 'publish', 'open', 'open', '', 'acdc-antes-das-contasdepois-das-contas', '', '', '2016-11-05 00:44:57', '2016-11-05 00:44:57', '', 0, 'https://medium.com/p/e3ec6ff0d4d0', 0, 'post', '', 0),
(25, 1, '2016-09-02 02:56:40', '2016-09-02 02:56:40', '<p>Adorei o texto, me fez lembrar do passado, comparar com o que penso agora (com outras experiencias) e acho que vou escrever alguma coisa baseado nesaa reflexão por qual me fez passar ao ler seu artigo.</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=629bc555698b" width="1" height="1">', 'Adorei o texto, me fez lembrar do passado, comparar com o que penso agora (com outras experiencias…', '', 'trash', 'open', 'open', '', 'adorei-o-texto-me-fez-lembrar-do-passado-comparar-com-o-que-penso-agora-com-outras-experiencias__trashed', '', '', '2016-11-05 00:37:55', '2016-11-05 00:37:55', '', 0, 'https://medium.com/p/629bc555698b', 0, 'post', '', 0),
(26, 1, '2016-06-07 17:33:59', '2016-06-07 17:33:59', '<h4>Muito além do dinheiro, deixar sua marca no mundo ou apenas colaborar por a disseminação de uma causa ou informação importante que possa conscientizar, educar e até mesmo divertir.</h4><figure><img alt="" src="https://d262ilb51hltx0.cloudfront.net/max/620/1*t1ay1GxgxCaZ6oz3FPyO-g.jpeg" /><figcaption>Elon Musk, Empreendedor pioneiro em pagamentos digitais (PayPal) e que sonha em baratear viagens espaciais (SpaceX) e tornar populares os carros elétricos (Tesla Motors).</figcaption></figure><p>Como sabem, o nosso Brasil está passando por um momento muito importante. Nunca se viu tanta gente cobrando e observando de perto a vida dos nossos políticos. Eu não sou uma pessoa tão engajada na politica a ponto de discutir com muita profundidade, mas me senti criativo em tentar disseminar um pouco de informação (mesmo com um humor não tão bem aceito) e meses atrás eu criei isto aqui:</p><p><a href="http://ogilvieira.github.io/planilha-odebrecht/">[TESTE] Quem é você na planilha da Odebrecht</a></p><p>É tão atual, que resolvi escrever este post e aproveitar para falar sobre como me sinto com um projeto destes. É excelente ter um feedback e ver discussões boas (e não violentos) sobre um projeto seu. A recompensa neste caso foi a de poder deixar minha marca, dizer “Eu ajudei”, foi motivador.</p><p>O que quero concluir (e que pretendo me aprofundar melhor em um futuro artigo) é o seguinte: Tenha motivações emocionais. Dedique-se algumas horas de sua semana em um romance entre você e uma atividade ou projeto que goste. Produza baseado nas suas paixões. É libertador e te livra do sentimento de obrigatoriedade e responsabilidades estressantes.</p><p>O texto foi curto e superficial, mas garanto que irei compensar no próximo artigo. Aguarde e confie :)</p><p>Considere dar uma olhada nestes outros posts:</p><ul><li><a href="https://medium.com/@ogilvieira/5-coisas-sobre-ser-autodidata-que-eu-diria-a-mim-mesmo-se-pudesse-voltar-no-tempo-de3006b1e61b">5 coisas sobre ser autodidata que eu diria a mim mesmo se pudesse voltar no tempo</a></li><li><a href="https://medium.com/@ogilvieira/n%C3%A3o-dependa-da-sua-for%C3%A7a-de-vontade-pois-ela-vai-falhar-49706d3baed8">Não dependa da sua força de vontade, pois ela vai falhar.</a></li><li><a href="https://woliveiras.com.br/posts/produtividade-uma-re-introducao/">Produtividade, uma re-introdução</a></li></ul><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=40946f23a1b9" width="1" height="1">', 'Empreendendo pela causa [DROPS]', '', 'publish', 'open', 'open', '', 'empreendendo-pela-causa-drops', '', '', '2016-11-05 00:43:38', '2016-11-05 00:43:38', '', 0, 'https://medium.com/p/40946f23a1b9', 0, 'post', '', 0),
(27, 1, '2016-05-24 14:29:21', '2016-05-24 14:29:21', '<p>Olá Douglas!</p><p>Na verdade é Gilmair Vieira, como ninguém acerta, acabou virando “Gil Vieira”, que mais tarde se tornou “Ogilvieira” pois é como as pessoas geralmente se dirigem a mim (Ô Gil Vieira…). Acabou que eu não sou nem só “Gil”, nem só “Vieira” e ainda tem um “O” como prefixo.</p><p>Cara, que bom que têm pessoas pensando igual quanto a isso, fiz um <a href="https://medium.com/@devjunior/5-coisas-sobre-ser-autodidata-que-eu-diria-a-mim-mesmo-se-pudesse-voltar-no-tempo-de3006b1e61b">post recente sobre o que aprendi sobre ser autodidata</a> e basicamente levei 5 anos para amadurecer meu aprendizado, destes, 3 eu estava sem saber o que estava fazendo direito e acabei errando mais do que acertando.</p><p>Não sou nenhum guru da produtividade e aprendizado, mas experimentei na pele o que é não ter recursos mas ter muita vontade. Experimento diariamente lutar contra meus hábitos e preconceitos ruins (preguiça, medo…) e este blog serve para exorcizar meus demônios e tentar ajudar caras que são o que eu era a 5 anos atrás: Um moleque que não aceitava que moraria no meio da favela e trabalharia escravizado em um emprego que odeia.</p><p>Basicamente o que tento “evangelizar” é que em um sistema de “meritocracia” injusta em que vivemos, devemos depender apenas de nós mesmos e fazer o que podemos com o que temos. De maneira crua, sem cases de sucessos onde se arrecada milhares de dólares com formulas mágicas de empreendedorismo e aprendizado.</p><p>Desculpa por ser um pouco negativo, pra compensar posso dizer que aqui a troca de experiência é mútua e você é muito bem vindo pra comentar. Estarei te seguindo para que, se vir a postar, eu possa colaborar de alguma forma.</p><p>Obrigado!</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=3c76e358dc59" width="1" height="1">', 'Olá Douglas!', '', 'trash', 'open', 'open', '', 'ola-douglas__trashed', '', '', '2016-11-05 00:37:55', '2016-11-05 00:37:55', '', 0, 'https://medium.com/p/3c76e358dc59', 0, 'post', '', 0),
(28, 1, '2016-11-05 00:37:51', '2016-11-05 00:37:51', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2016-11-05 00:37:51', '2016-11-05 00:37:51', '', 1, 'http:1motivo.web2423.uni5.net/uncategorized/1-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2016-11-05 00:37:52', '2016-11-05 00:37:52', '<p>Obrigado <a href="https://medium.com/u/d270872c8b23">Luan Vicente</a>! Eu sou um portador (de verdade) de TDAH. Eu tive que escolher em basear minha vida em remédios controladores ou criar alguma disciplina e estratégias para combater as coisas ruins que me atrapalham por causa dessa condição. Depois de muita leitura nesses últimos 5 anos alguma coisa de experiência eu tenho para contar hehehe. Obrigado! tomara que eu consiga produzir mais coisas que sejam minimamente úteis pra quem tem problemas parecidos com os meus. Até mais!</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=5794419e5d79" width="1" height="1">', 'Obrigado Luan Vicente!', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2016-11-05 00:37:52', '2016-11-05 00:37:52', '', 18, 'http:1motivo.web2423.uni5.net/uncategorized/18-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2016-11-05 00:37:52', '2016-11-05 00:37:52', '<p>Me sinto seguro no ônibus. Raramente pode acontecer de aparecer alguem estranho, geralmente é tranquilo para usar smartphone, kindle…</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=97838e223517" width="1" height="1">', 'Me sinto seguro no ônibus.', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2016-11-05 00:37:52', '2016-11-05 00:37:52', '', 19, 'http:1motivo.web2423.uni5.net/uncategorized/19-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2016-11-05 00:37:53', '2016-11-05 00:37:53', '<p>Eu tinha o mesmo problema, resolvi criando uma conta gmail pro youtube para me inscrever apenas em canais de video aula. Quem sabe isso pode te ajudar também.</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=be2c75de30ff" width="1" height="1">', 'Eu tinha o mesmo problema, resolvi criando uma conta gmail pro youtube para me inscrever apenas em…', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2016-11-05 00:37:53', '2016-11-05 00:37:53', '', 20, 'http:1motivo.web2423.uni5.net/uncategorized/20-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2016-11-05 00:37:54', '2016-11-05 00:37:54', '<p>Com bilhete único mensal, vc paga 140 e pode rodar quantas vezes quiser de ônibus por mês… fica a dica! Ônibus para o trabalho é muito vantajoso quanto a otimização de tempo, eu apoio!</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=8e78970d77dc" width="1" height="1">', 'Com bilhete único mensal, vc paga 140 e pode rodar quantas vezes quiser de ônibus por mês… fica a…', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2016-11-05 00:37:54', '2016-11-05 00:37:54', '', 21, 'http:1motivo.web2423.uni5.net/uncategorized/21-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2016-11-05 00:37:54', '2016-11-05 00:37:54', '<p>Estou aqui pela premonição contida neste titulo e imagem de destaque</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=572f4a21d402" width="1" height="1">', 'Estou aqui pela premonição contida neste titulo e imagem de destaque', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2016-11-05 00:37:54', '2016-11-05 00:37:54', '', 22, 'http:1motivo.web2423.uni5.net/uncategorized/22-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2016-11-05 00:37:55', '2016-11-05 00:37:55', '<p>Adorei o texto, me fez lembrar do passado, comparar com o que penso agora (com outras experiencias) e acho que vou escrever alguma coisa baseado nesaa reflexão por qual me fez passar ao ler seu artigo.</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=629bc555698b" width="1" height="1">', 'Adorei o texto, me fez lembrar do passado, comparar com o que penso agora (com outras experiencias…', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-11-05 00:37:55', '2016-11-05 00:37:55', '', 25, 'http:1motivo.web2423.uni5.net/uncategorized/25-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2016-11-05 00:37:55', '2016-11-05 00:37:55', '<p>Olá Douglas!</p><p>Na verdade é Gilmair Vieira, como ninguém acerta, acabou virando “Gil Vieira”, que mais tarde se tornou “Ogilvieira” pois é como as pessoas geralmente se dirigem a mim (Ô Gil Vieira…). Acabou que eu não sou nem só “Gil”, nem só “Vieira” e ainda tem um “O” como prefixo.</p><p>Cara, que bom que têm pessoas pensando igual quanto a isso, fiz um <a href="https://medium.com/@devjunior/5-coisas-sobre-ser-autodidata-que-eu-diria-a-mim-mesmo-se-pudesse-voltar-no-tempo-de3006b1e61b">post recente sobre o que aprendi sobre ser autodidata</a> e basicamente levei 5 anos para amadurecer meu aprendizado, destes, 3 eu estava sem saber o que estava fazendo direito e acabei errando mais do que acertando.</p><p>Não sou nenhum guru da produtividade e aprendizado, mas experimentei na pele o que é não ter recursos mas ter muita vontade. Experimento diariamente lutar contra meus hábitos e preconceitos ruins (preguiça, medo…) e este blog serve para exorcizar meus demônios e tentar ajudar caras que são o que eu era a 5 anos atrás: Um moleque que não aceitava que moraria no meio da favela e trabalharia escravizado em um emprego que odeia.</p><p>Basicamente o que tento “evangelizar” é que em um sistema de “meritocracia” injusta em que vivemos, devemos depender apenas de nós mesmos e fazer o que podemos com o que temos. De maneira crua, sem cases de sucessos onde se arrecada milhares de dólares com formulas mágicas de empreendedorismo e aprendizado.</p><p>Desculpa por ser um pouco negativo, pra compensar posso dizer que aqui a troca de experiência é mútua e você é muito bem vindo pra comentar. Estarei te seguindo para que, se vir a postar, eu possa colaborar de alguma forma.</p><p>Obrigado!</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=3c76e358dc59" width="1" height="1">', 'Olá Douglas!', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2016-11-05 00:37:55', '2016-11-05 00:37:55', '', 27, 'http:1motivo.web2423.uni5.net/uncategorized/27-revision-v1/', 0, 'revision', '', 0),
(36, 1, '2016-11-05 00:43:38', '2016-11-05 00:43:38', '<h4>Muito além do dinheiro, deixar sua marca no mundo ou apenas colaborar por a disseminação de uma causa ou informação importante que possa conscientizar, educar e até mesmo divertir.</h4><figure><img alt="" src="https://d262ilb51hltx0.cloudfront.net/max/620/1*t1ay1GxgxCaZ6oz3FPyO-g.jpeg" /><figcaption>Elon Musk, Empreendedor pioneiro em pagamentos digitais (PayPal) e que sonha em baratear viagens espaciais (SpaceX) e tornar populares os carros elétricos (Tesla Motors).</figcaption></figure><p>Como sabem, o nosso Brasil está passando por um momento muito importante. Nunca se viu tanta gente cobrando e observando de perto a vida dos nossos políticos. Eu não sou uma pessoa tão engajada na politica a ponto de discutir com muita profundidade, mas me senti criativo em tentar disseminar um pouco de informação (mesmo com um humor não tão bem aceito) e meses atrás eu criei isto aqui:</p><p><a href="http://ogilvieira.github.io/planilha-odebrecht/">[TESTE] Quem é você na planilha da Odebrecht</a></p><p>É tão atual, que resolvi escrever este post e aproveitar para falar sobre como me sinto com um projeto destes. É excelente ter um feedback e ver discussões boas (e não violentos) sobre um projeto seu. A recompensa neste caso foi a de poder deixar minha marca, dizer “Eu ajudei”, foi motivador.</p><p>O que quero concluir (e que pretendo me aprofundar melhor em um futuro artigo) é o seguinte: Tenha motivações emocionais. Dedique-se algumas horas de sua semana em um romance entre você e uma atividade ou projeto que goste. Produza baseado nas suas paixões. É libertador e te livra do sentimento de obrigatoriedade e responsabilidades estressantes.</p><p>O texto foi curto e superficial, mas garanto que irei compensar no próximo artigo. Aguarde e confie :)</p><p>Considere dar uma olhada nestes outros posts:</p><ul><li><a href="https://medium.com/@ogilvieira/5-coisas-sobre-ser-autodidata-que-eu-diria-a-mim-mesmo-se-pudesse-voltar-no-tempo-de3006b1e61b">5 coisas sobre ser autodidata que eu diria a mim mesmo se pudesse voltar no tempo</a></li><li><a href="https://medium.com/@ogilvieira/n%C3%A3o-dependa-da-sua-for%C3%A7a-de-vontade-pois-ela-vai-falhar-49706d3baed8">Não dependa da sua força de vontade, pois ela vai falhar.</a></li><li><a href="https://woliveiras.com.br/posts/produtividade-uma-re-introducao/">Produtividade, uma re-introdução</a></li></ul><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=40946f23a1b9" width="1" height="1">', 'Empreendendo pela causa [DROPS]', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2016-11-05 00:43:38', '2016-11-05 00:43:38', '', 26, 'http:1motivo.web2423.uni5.net/uncategorized/26-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2016-11-05 00:44:57', '2016-11-05 00:44:57', '<h4>Sobre como passamos de jovens rebeldes descontrutores de conceitos a pais de família vítimas de uma sociedade doente.</h4><p>Houve um tempo em que “levar uma vida sem pressão” era um dos meus conselhos; “Deixar que as coisas acontecessem naturalmente” era minha filosofia de vida. Esse tempo morreu no dia em que nasceu minha independência.</p><figure><img alt="" src="https://d262ilb51hltx0.cloudfront.net/max/1024/1*t2No4W1-MuYXG6yB97tFeg.jpeg" /></figure><p>Alguém aparentemente bem sucedido (sem esforço aparente) vai dizer que você não precisa levar a vida a tão sério e que um mochilão pela Europa vai mudar sua vida. Se você não pertence a classe alta deste país, vem comigo neste artigo.</p><p>Quando se mora com os pais, as tarefas domésticas magicamente acontecem. Não nos é muito nítido o quão difícil é administrar uma família. Para uma criação razoável de nossa prole é necessário prover saúde, alimentação, transporte, educação e uma internet boa para que seu filhote possa mostrar a todos o quanto revolucionário ele é, “FUCK THE SYSTEM!”, Certo!?</p><p>Nós eramos mais jovens, queríamos mudar o mundo e o mundo foi quem nos mudou. A sociedade que tanto odiamos coloca a música e vamos arriscando os passos para tentar acompanhar e não ficar de fora do baile. Alguns vieram preparados com seus MBA’s de sapateados e outros são dançarinos dedicados. Deixar esses caras pegarem seu espaço na pista é perder mais que glamour de ser um bom dançarino, é ter que ver seu filho correndo risco de vida por causa de um plano de saúde merda, ter que ver sua filha frustrada por não poder fazer o que ama ou não pagar a internet para que o filhão possa falar sobre “o que os adultos estão fazendo de suas vidas é errado”, pobres adultos, deveriam ouvir meu conselho e fugir desse sistema podre.</p><p>Hey kid, é tudo que gostaríamos de fazer sabe... Infelizmente as contas não param de chegar e sem uma educação de qualidade o junior terá que sofrer tanto quanto ou quem sabe mais que eu, para tentar manter as coisas ordens, <strong>como nossos pais…</strong></p><h4>Ainda somos jovens</h4><p>Manter o equilíbrio é essencial. Entre tentar mudar o mundo e expor a minha arte, há um espaço reservado para bater ponto, ser inovador, aprender algo técnico e flertar por um aumento merecido, quem sabe.</p><p>Outro dia, aqui em São Paulo, um homem desempregado pulou com seu filho de 4 anos do prédio do Fórum Trabalhista. Os dois morreram.</p><p>Da pra imaginar o que se passou pela cabeça daquele homem. Mais uma vítima dessa sociedade patriarcal doente. Eles falam de meritocracia, quem merece sofrer por não ter perspectiva de poder sustentar os filhos?</p><p>Ela, a sociedade, nos faz chorar. E eu choro sim! Não é nada fácil manter as coisas, sabe… Penso em desistir sim, mas lembro que é isso que eles querem e eu não vou deixar.</p><figure><img alt="" src="https://d262ilb51hltx0.cloudfront.net/max/1024/1*MtoVSZapAe99duNQQkzxuA.jpeg" /></figure><h4>Mesmo assim, a vida ainda é bela</h4><p>Acompanhar uma criança crescer, alimentar o lúdico, compartilhar nossas experiências como neste artigo aqui e perceber que em nossas individualidades estamos sendo acompanhados por pessoas que passam pelos mesmos dilemas, medos e dificuldades.</p><p>Por isso, jovem, não leve a vida tão a sério, todo buraco tem saída independente da profundidade; Mas também não amoleça, a vida vai bater forte, e você tem que estar preparado para aguentar firme e continuar levantando.</p><iframe src="https://cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2F85tRr6_1FXQ%3Ffeature%3Doembed&amp;url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D85tRr6_1FXQ&amp;image=https%3A%2F%2Fi.ytimg.com%2Fvi%2F85tRr6_1FXQ%2Fhqdefault.jpg&amp;key=d04bfffea46d4aeda930ec88cc64b87c&amp;type=text%2Fhtml&amp;schema=youtube" width="640" height="480" frameborder="0" scrolling="no"><a href="https://medium.com/media/2d502ca6a187e139ac95e55f1d5c6a19/href">https://medium.com/media/2d502ca6a187e139ac95e55f1d5c6a19/href</a></iframe><p>Gostou do artigo? Deixe aquele seu like motivacional ai!. Se preferir, deixe um comentário e compartilhe o artigo.</p><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=e3ec6ff0d4d0" width="1" height="1">', 'AC/DC (Antes das Contas/Depois das Contas)', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2016-11-05 00:44:57', '2016-11-05 00:44:57', '', 24, 'http:1motivo.web2423.uni5.net/sem-categoria/24-revision-v1/', 0, 'revision', '', 0),
(38, 1, '2016-11-05 00:45:56', '2016-11-05 00:45:56', '<h4>Um guia realista sobre como se esquivar dessa falta de coragem para realizar coisas.</h4><figure><img alt="" src="https://d262ilb51hltx0.cloudfront.net/max/1024/1*u3znrnUxKFqDrzan9AV6pQ.png" /><figcaption>Se você é do tipo que realmente precisa ler este artigo, é muito provável que não passe daqui…</figcaption></figure><p>Ok, você já sabe que todos nós sofremos com preguiça, alguns de nós são verdadeiras mulas empacadas no sofá pois, “Por inércia, um corpo em repouso tende a continuar em repouso”.</p><p>Você provavelmente também já sabe, caso já tenha procurado ajuda na internet antes, que o melhor jeito de se livrar da preguiça é “<strong>Fazer Algo</strong>”, quem sabe acordar ás 6 da manhã e fazer exercícios…</p><p>O meu problema com isso é o seguinte:</p><blockquote>Como fazer algo para se livrar da preguiça sendo que a preguiça não me deixa fazer algo?</blockquote><iframe src="https://cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fgiphy.com%2Fembed%2Fp7xQlayxs6Uda%2Ftwitter%2Fiframe&amp;src_secure=1&amp;url=http%3A%2F%2Fgiphy.com%2Fgifs%2Fp7xQlayxs6Uda&amp;image=https%3A%2F%2Fmedia.giphy.com%2Fmedia%2Fp7xQlayxs6Uda%2Fgiphy.gif&amp;key=d04bfffea46d4aeda930ec88cc64b87c&amp;type=text%2Fhtml&amp;schema=giphy" width="435" height="245" frameborder="0" scrolling="no"><a href="https://medium.com/media/970056323d3d340b6ce1b811ca22f436/href">https://medium.com/media/970056323d3d340b6ce1b811ca22f436/href</a></iframe><h3>Aceitando a Derrota</h3><p>Sejamos honestos, a preguiça sempre ira vencer e você sabe disso; a Netflix sabe disso; o YouTube sabe disso e mantem uma playlist reservada pra te foder no limbo da procrastinação. Para nos livrarmos das amarras da “Falta de vontade de fazer qualquer coisa”, vamos precisar de atitudes simples que possam ser realizadas mesmo naquelas manhãs de domingo.</p><h4>1) Dormir de forma inteligente</h4><p>O sono é composto de <a href="http://www.sono.org.br/sono/sono.php">ciclos</a> de 1h30m entre o estados mais profundo (REM) e mais leve. A sensação de cansaço ao acordar geralmente é maior quando você é despertado durante o estágio do sono REM, sabendo disso, você pode usar <a href="https://play.google.com/store/apps/details?id=com.cycle.sleepcalculator">apps que calculam o melhor horário para acordar</a> com base na hora em que pretende dormir. Programe o alarme para te acordar no momento exato sem perder disposição, e pronto.</p><h4>2) Fazer pouco é melhor que fazer nada</h4><figure><img alt="" src="https://d262ilb51hltx0.cloudfront.net/max/690/1*oUeJDE0pNDbrdGHD1H_ksQ.jpeg" /></figure><p>Se você planeja criar um novo hábito, como escrever um blog, por exemplo, você pode tentar se cobrar de escrever apenas uma linha por dia. Isso mesmo, vá aos poucos, o mais importante é a ignição, se não rolar tudo bem, volte amanhã e tente outra vez.</p><h4>3) Pequenas tarefas criam grandes monstros</h4><p>Evite deixar que pequenas tarefas se acumulem, pegue tudo que for muito fácil e rápido de se fazer e apenas faça.</p><h4>4) Divida tarefas longas em partes menores</h4><p>Se você nunca ouviu falar da técnica Pomodoro, saiba que esta perdendo uma das grandes soluções anti-procrastinação na hora de encarar tarefas grandes. Na técnica Pomodoro, basicamente, você divide o tempo em ciclos de 25 minutos para focar em sua tarefa e mais 5 minutos de pausa fazendo algo que goste. a cada 4 ciclos, tire uma pausa maior de 15 minutos. Você pode procurar por <strong>Pomodoro</strong> em sua app store, existem diversos aplicativos para ajudar a gerenciar estes ciclos.</p><figure><img alt="" src="https://d262ilb51hltx0.cloudfront.net/max/1024/1*kZzipFPSUMrR12ymvrxE1Q.jpeg" /></figure><p>O Pomodoro ajuda a se sentir recompensado pelo trabalho nas pausas, e aumentar sua produtiva nos momentos de foco absoluto. <a href="https://pt.wikipedia.org/wiki/T%C3%A9cnica_pomodoro">Saiba mais aqui</a>.</p><h4><strong>5) Dificulte a procrastinação</strong></h4><p>Se você se perde no buraco negro de links do YouTube, Medium, Facebook, Twitter… saiba que dá pra fugir com soluções simples: Você pode usar extensões para Chrome como o <a href="https://chrome.google.com/webstore/detail/block-site/eiimnmioipafcokbfikbljfdeojpcgbh?hl=en">Block Site</a>, bloquear os sites que estão te atrapalhando com senha. Eu peço para alguém criar a senha pra mim, fica mais difícil burlar quando você tem essa barreira social colaborando para sua desistência de procrastinar.</p><p>No Smartphone a solução é mais simples ainda: Desinstale todos os aplicativos que só servem para te atrapalhar, e isso inclui o Whatsapp. Vá por mim, as pessoas com quem você realmente precisa falar vão te ligar ou estarão sempre perto de você.</p><h4>6) Procure um médico</h4><p>É importante avisar que a preguiça pode estar associadas a algumas doenças e deficiências de vitaminas. Se mesmo com essas dicas você ainda não conseguiu vencer a preguiça, pense a respeito sobre procurar a ajuda de um médico.</p><h3>Conclusão</h3><p>Gosto de pensar que a preguiça só existe quando as coisas estão minimamente confortáveis para nós, mamíferos que repousamos quando não há necessidade de procurar comida ou fugir do predador. Mesmo assim, a roda tem que continuar a rodar e com pequenos hacks podemos manipular nossos instintos e alcançar nossos objetivos. Como já falei em outro artigo: <a href="https://medium.com/@ogilvieira/n%C3%A3o-dependa-da-sua-for%C3%A7a-de-vontade-pois-ela-vai-falhar-49706d3baed8#.57shk5rj2">Não dependa da sua força de vontade, pois ela vai falhar.</a></p><ul><li><a href="https://medium.com/@ogilvieira/como-aprender-mais-r%C3%A1pido-ed671efdcf47">Como aprender qualquer coisa sozinho, com pouca grana e muito mais rápido</a></li><li><a href="https://medium.com/@ogilvieira/5-coisas-sobre-ser-autodidata-que-eu-diria-a-mim-mesmo-se-pudesse-voltar-no-tempo-de3006b1e61b">5 coisas sobre ser autodidata que eu diria a mim mesmo se pudesse voltar no tempo</a></li></ul><img src="https://medium.com/_/stat?event=post.clientViewed&referrerSource=full_rss&postId=b5bfdf14c719" width="1" height="1">', 'Como se livrar da PREGUIÇA fazendo pouco, ou quase nada', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2016-11-05 00:45:56', '2016-11-05 00:45:56', '', 23, 'http:1motivo.web2423.uni5.net/sem-categoria/23-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `1m_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(39, 1, '2016-11-05 00:54:22', '2016-11-05 00:54:22', '<h4>Um guia realista sobre como se esquivar dessa falta de coragem para realizar coisas.</h4>\r\n<figure><img src="https://d262ilb51hltx0.cloudfront.net/max/1024/1*u3znrnUxKFqDrzan9AV6pQ.png" alt="" />\r\n<figcaption>Se você é do tipo que realmente precisa ler este artigo, é muito provável que não passe daqui…</figcaption></figure>Ok, você já sabe que todos nós sofremos com preguiça, alguns de nós são verdadeiras mulas empacadas no sofá pois, “Por inércia, um corpo em repouso tende a continuar em repouso”.\r\n\r\nVocê provavelmente também já sabe, caso já tenha procurado ajuda na internet antes, que o melhor jeito de se livrar da preguiça é “<strong>Fazer Algo</strong>”, quem sabe acordar ás 6 da manhã e fazer exercícios…\r\n\r\nO meu problema com isso é o seguinte:\r\n<blockquote>Como fazer algo para se livrar da preguiça sendo que a preguiça não me deixa fazer algo?</blockquote>\r\n<img class="aligncenter size-medium" src="https://media.giphy.com/media/p7xQlayxs6Uda/giphy.gif" alt="" width="400" height="226" />\r\n<h3></h3>\r\n<h3>Aceitando a Derrota</h3>\r\nSejamos honestos, a preguiça sempre ira vencer e você sabe disso; a Netflix sabe disso; o YouTube sabe disso e mantem uma playlist reservada pra te foder no limbo da procrastinação. Para nos livrarmos das amarras da “Falta de vontade de fazer qualquer coisa”, vamos precisar de atitudes simples que possam ser realizadas mesmo naquelas manhãs de domingo.\r\n<h4>1) Dormir de forma inteligente</h4>\r\nO sono é composto de <a href="http://www.sono.org.br/sono/sono.php">ciclos</a> de 1h30m entre o estados mais profundo (REM) e mais leve. A sensação de cansaço ao acordar geralmente é maior quando você é despertado durante o estágio do sono REM, sabendo disso, você pode usar <a href="https://play.google.com/store/apps/details?id=com.cycle.sleepcalculator">apps que calculam o melhor horário para acordar</a> com base na hora em que pretende dormir. Programe o alarme para te acordar no momento exato sem perder disposição, e pronto.\r\n<h4>2) Fazer pouco é melhor que fazer nada</h4>\r\n<figure><img src="https://d262ilb51hltx0.cloudfront.net/max/690/1*oUeJDE0pNDbrdGHD1H_ksQ.jpeg" alt="" /></figure>Se você planeja criar um novo hábito, como escrever um blog, por exemplo, você pode tentar se cobrar de escrever apenas uma linha por dia. Isso mesmo, vá aos poucos, o mais importante é a ignição, se não rolar tudo bem, volte amanhã e tente outra vez.\r\n<h4>3) Pequenas tarefas criam grandes monstros</h4>\r\nEvite deixar que pequenas tarefas se acumulem, pegue tudo que for muito fácil e rápido de se fazer e apenas faça.\r\n<h4>4) Divida tarefas longas em partes menores</h4>\r\nSe você nunca ouviu falar da técnica Pomodoro, saiba que esta perdendo uma das grandes soluções anti-procrastinação na hora de encarar tarefas grandes. Na técnica Pomodoro, basicamente, você divide o tempo em ciclos de 25 minutos para focar em sua tarefa e mais 5 minutos de pausa fazendo algo que goste. a cada 4 ciclos, tire uma pausa maior de 15 minutos. Você pode procurar por <strong>Pomodoro</strong> em sua app store, existem diversos aplicativos para ajudar a gerenciar estes ciclos.\r\n\r\n<figure><img src="https://d262ilb51hltx0.cloudfront.net/max/1024/1*kZzipFPSUMrR12ymvrxE1Q.jpeg" alt="" /></figure>O Pomodoro ajuda a se sentir recompensado pelo trabalho nas pausas, e aumentar sua produtiva nos momentos de foco absoluto. <a href="https://pt.wikipedia.org/wiki/T%C3%A9cnica_pomodoro">Saiba mais aqui</a>.\r\n<h4><strong>5) Dificulte a procrastinação</strong></h4>\r\nSe você se perde no buraco negro de links do YouTube, Medium, Facebook, Twitter… saiba que dá pra fugir com soluções simples: Você pode usar extensões para Chrome como o <a href="https://chrome.google.com/webstore/detail/block-site/eiimnmioipafcokbfikbljfdeojpcgbh?hl=en">Block Site</a>, bloquear os sites que estão te atrapalhando com senha. Eu peço para alguém criar a senha pra mim, fica mais difícil burlar quando você tem essa barreira social colaborando para sua desistência de procrastinar.\r\n\r\nNo Smartphone a solução é mais simples ainda: Desinstale todos os aplicativos que só servem para te atrapalhar, e isso inclui o Whatsapp. Vá por mim, as pessoas com quem você realmente precisa falar vão te ligar ou estarão sempre perto de você.\r\n<h4>6) Procure um médico</h4>\r\nÉ importante avisar que a preguiça pode estar associadas a algumas doenças e deficiências de vitaminas. Se mesmo com essas dicas você ainda não conseguiu vencer a preguiça, pense a respeito sobre procurar a ajuda de um médico.\r\n<h3>Conclusão</h3>\r\nGosto de pensar que a preguiça só existe quando as coisas estão minimamente confortáveis para nós, mamíferos que repousamos quando não há necessidade de procurar comida ou fugir do predador. Mesmo assim, a roda tem que continuar a rodar e com pequenos hacks podemos manipular nossos instintos e alcançar nossos objetivos. Como já falei em outro artigo: <a href="https://medium.com/@ogilvieira/n%C3%A3o-dependa-da-sua-for%C3%A7a-de-vontade-pois-ela-vai-falhar-49706d3baed8#.57shk5rj2">Não dependa da sua força de vontade, pois ela vai falhar.</a>\r\n<ul>\r\n 	<li><a href="https://medium.com/@ogilvieira/como-aprender-mais-r%C3%A1pido-ed671efdcf47">Como aprender qualquer coisa sozinho, com pouca grana e muito mais rápido</a></li>\r\n 	<li><a href="https://medium.com/@ogilvieira/5-coisas-sobre-ser-autodidata-que-eu-diria-a-mim-mesmo-se-pudesse-voltar-no-tempo-de3006b1e61b">5 coisas sobre ser autodidata que eu diria a mim mesmo se pudesse voltar no tempo</a></li>\r\n</ul>\r\n<img src="https://medium.com/_/stat?event=post.clientViewed&amp;referrerSource=full_rss&amp;postId=b5bfdf14c719" width="1" height="1" />', 'Como se livrar da PREGUIÇA fazendo pouco, ou quase nada', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2016-11-05 00:54:22', '2016-11-05 00:54:22', '', 23, 'http:1motivo.web2423.uni5.net/sem-categoria/23-revision-v1/', 0, 'revision', '', 0) ;

#
# Fim do conteúdo da tabela `1m_posts`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_term_relationships` existente
#

DROP TABLE IF EXISTS `1m_term_relationships`;


#
# Estrutura da tabela `1m_term_relationships`
#

CREATE TABLE `1m_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Conteúdo da tabela `1m_term_relationships`
#
INSERT INTO `1m_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(9, 2, 0),
(10, 2, 0),
(12, 2, 0),
(13, 2, 0),
(14, 2, 0),
(15, 2, 0),
(18, 1, 0),
(19, 1, 0),
(20, 1, 0),
(21, 1, 0),
(22, 1, 0),
(23, 14, 0),
(24, 12, 0),
(24, 13, 0),
(25, 1, 0),
(26, 11, 0),
(27, 1, 0) ;

#
# Fim do conteúdo da tabela `1m_term_relationships`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_term_taxonomy` existente
#

DROP TABLE IF EXISTS `1m_term_taxonomy`;


#
# Estrutura da tabela `1m_term_taxonomy`
#

CREATE TABLE `1m_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_term_taxonomy`
#
INSERT INTO `1m_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 6),
(11, 11, 'category', '', 0, 1),
(12, 12, 'category', '', 0, 1),
(13, 13, 'category', '', 0, 1),
(14, 14, 'category', '', 0, 1) ;

#
# Fim do conteúdo da tabela `1m_term_taxonomy`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_termmeta` existente
#

DROP TABLE IF EXISTS `1m_termmeta`;


#
# Estrutura da tabela `1m_termmeta`
#

CREATE TABLE `1m_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_termmeta`
#

#
# Fim do conteúdo da tabela `1m_termmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_terms` existente
#

DROP TABLE IF EXISTS `1m_terms`;


#
# Estrutura da tabela `1m_terms`
#

CREATE TABLE `1m_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_terms`
#
INSERT INTO `1m_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Sem Categoria', 'sem-categoria', 0),
(2, 'Menu 1', 'menu-1', 0),
(11, 'Empreendedorismo', 'empreendedorismo', 0),
(12, 'Motivacional', 'motivacional', 0),
(13, 'Estilo De Vida', 'estilo-de-vida', 0),
(14, 'Produtividade', 'produtividade', 0) ;

#
# Fim do conteúdo da tabela `1m_terms`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_usermeta` existente
#

DROP TABLE IF EXISTS `1m_usermeta`;


#
# Estrutura da tabela `1m_usermeta`
#

CREATE TABLE `1m_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_usermeta`
#
INSERT INTO `1m_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'ogilvieira'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, '1m_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, '1m_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:1:{s:64:"1f40a0b8b1a383c7613dd3f3b7e8fb1b564c259434ca0081d488227c2e52f841";i:1478468235;}'),
(15, 1, '1m_dashboard_quick_press_last_post_id', '3'),
(16, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(17, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(18, 1, 'nav_menu_recently_edited', '2'),
(19, 1, '1m_user-settings', 'editor=tinymce&libraryContent=browse'),
(20, 1, '1m_user-settings-time', '1478311018') ;

#
# Fim do conteúdo da tabela `1m_usermeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `1m_users` existente
#

DROP TABLE IF EXISTS `1m_users`;


#
# Estrutura da tabela `1m_users`
#

CREATE TABLE `1m_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Conteúdo da tabela `1m_users`
#
INSERT INTO `1m_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'ogilvieira', '$P$Bsdt67Q.r1mqOL4YAGDRFPqVUZknPg.', 'ogilvieira', 'ogilvieira@gmail.com', '', '2016-11-04 21:36:59', '', 0, 'ogilvieira') ;

#
# Fim do conteúdo da tabela `1m_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

